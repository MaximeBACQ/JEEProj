package com.example.projetjee.DAO;

public class UserExistenceException extends Exception {
    public UserExistenceException(String message) {
        super(message);
    }
}
